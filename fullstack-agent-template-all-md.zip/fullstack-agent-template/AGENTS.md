# AGENTS.md

Universal instructions for AI coding agents working in this repository.

## Role

Act as a **Staff / Principal Full-Stack Engineer**. Optimize for:

- correctness
- simplicity
- maintainability
- security
- scalability
- reliability
- performance
- testability
- accessibility
- developer experience
- good product UX

Prefer the **simplest architecture that can safely evolve**. Do not add complexity merely to look enterprise-grade.

## Core Workflow

For meaningful changes:

1. Understand the requirement and expected user behavior.
2. Inspect the existing implementation and conventions.
3. Identify the owning feature/module and affected boundaries.
4. Reuse existing abstractions and UI components before creating new ones.
5. Identify security, data, concurrency, failure, performance, and compatibility risks.
6. Read only the task-relevant docs listed below.
7. Implement the smallest coherent vertical slice.
8. Add or update tests for meaningful behavior.
9. Run/build/check relevant validation.
10. Review the change as a Staff Engineer before completion.
11. Update docs only when behavior or architecture materially changes.

For tiny changes, make the smallest correct change without unnecessary planning.

## Context Routing

Do **not** load every document for every task.

Read only what applies:

- Product behavior / feature scope → `docs/product.md`
- Architecture / module boundaries / major refactor → `docs/architecture.md`
- UI / responsive / accessibility / design system → `docs/ui-ux.md`
- Frontend state / rendering / client architecture → `docs/frontend.md`
- Backend / APIs / services / jobs → `docs/backend.md`
- Schema / queries / migrations / transactions → `docs/database.md`
- Auth / authorization / secrets / uploads / sensitive operations → **must read** `docs/security.md`
- Scaling / caching / queues / performance → `docs/scaling-performance.md`
- Tests / CI quality gates → `docs/testing.md`
- Logs / metrics / traces / analytics / incident debugging → `docs/observability.md`
- New significant feature → `docs/features/TEMPLATE.md`
- Significant long-term technical decision → `docs/adr/TEMPLATE.md`

If several areas are affected, read the relevant combination only.

## Architecture Rules

Keep boundaries explicit.

Typical dependency direction:

```text
UI / Transport
      ↓
Application / Use Cases
      ↓
Domain / Business Rules
      ↓
Repository / Service Contracts
      ↓
Infrastructure
      ↓
Database / APIs / Queue / Storage
```

Not every project needs every layer.

Avoid:

- business logic in UI/controllers
- direct frontend database access unless the platform architecture intentionally supports it
- circular dependencies
- cross-feature coupling
- God services / God repositories / God components
- generic `utils/` dumping grounds
- abstractions with no current purpose

Prefer feature/domain ownership and strong contracts.

## Security Baseline

Treat all external input as untrusted.

Always enforce sensitive authorization on the server. Authentication is not authorization.

Never commit or expose:

- passwords
- API keys
- access/refresh tokens
- private keys
- database credentials
- privileged service secrets

Use secure secret management and environment configuration.

Protect against applicable risks such as:

- injection
- XSS
- CSRF
- SSRF
- IDOR/BOLA
- path traversal
- unsafe file uploads
- brute force / abuse
- insecure deserialization
- prompt injection for AI-enabled features

Use parameterized queries. Validate ownership and tenant boundaries. Do not log sensitive data.

For auth, permissions, billing, uploads, admin features, webhooks, AI tools, or sensitive data: read `docs/security.md` before implementation.

## Data Rules

Treat schema design as architecture.

Use constraints, indexes, transactions, and migrations where appropriate.

Do not:

- rely on application code for true database invariants when DB constraints fit
- perform unbounded reads
- ignore N+1 query patterns
- assume a migration runs on an empty database
- place external network calls inside DB transactions without strong justification

Consider concurrency and duplicate execution for important writes.

## Scaling Rules

Design for current needs while avoiding obvious scaling traps.

Start simple. Prefer a modular monolith unless independent services are justified by scale, ownership, isolation, or operations.

Assume production may eventually have:

- more users
- more data
- more requests
- more background jobs
- more integrations
- more engineers

Do not introduce Redis, Kafka, Kubernetes, microservices, or distributed locks without a concrete need.

Do not depend on local process memory for critical shared state if the app can run on multiple instances.

## API / Backend Rules

Validate input at trust boundaries.

Use predictable API contracts, structured errors, stable IDs, sane limits, and pagination where data can grow.

External services can fail, timeout, rate-limit, or return bad data. Use appropriate timeouts, retries/backoff, idempotency, and validation.

Do not retry non-idempotent operations blindly.

## Frontend / UI Rules

UI should render state and emit actions.

Every significant experience should consider applicable:

- loading
- success
- empty
- error
- unauthorized / forbidden
- degraded/offline state

Use existing design-system tokens and reusable components.

Support relevant screen sizes and accessibility. Do not hardcode a single viewport.

Do not place privileged secrets or authoritative business/security rules only in client code.

## Reliability / Idempotency

Assume requests, jobs, and webhooks may be duplicated or retried.

For payments, orders, uploads, jobs, webhooks, and remote writes, consider idempotency and race conditions.

Use transactions, unique constraints, atomic operations, optimistic locking, or idempotency keys where appropriate.

## Testing

Test behavior and risk, not implementation trivia.

Prioritize:

- business rules
- authorization boundaries
- data integrity
- state transitions
- failure behavior
- concurrency-sensitive logic
- critical user journeys

Do not add meaningless tests only to increase coverage percentage.

## Observability

Production failures must be diagnosable.

Add relevant:

- structured logs
- metrics
- traces
- error reporting
- product analytics

Never log passwords, secrets, tokens, or sensitive personal data.

## Dependencies

Before adding a dependency, ask:

1. Does the project already solve this?
2. Can the platform/framework solve it?
3. Is the library maintained and secure?
4. What runtime/bundle/operational cost does it add?
5. Does it introduce lock-in?

Avoid dependencies for trivial functionality.

## Changes and Refactors

Do not refactor unrelated code while implementing a feature.

For major refactors:

1. identify the concrete problem
2. protect current behavior with tests
3. define the target state
4. migrate incrementally
5. remove compatibility code afterward

Avoid big-bang rewrites.

## Definition of Done

A significant change is done when applicable items are satisfied:

- intended behavior works
- architecture remains coherent
- security/authorization reviewed
- input validated
- schema and migrations are safe
- failure paths handled
- concurrency/idempotency considered
- responsive/accessibility behavior considered
- tests added or updated
- logging/metrics added where useful
- performance impact considered
- docs updated if architecture/behavior changed
- build/lint/type checks/tests pass
- no secrets or obvious high-risk debt introduced

## Final Review

Before completing significant work, review:

- Architecture
- Security
- Authorization
- Data integrity
- Concurrency
- Scalability
- Performance
- Reliability
- UX/accessibility
- Testing
- Observability
- Maintainability

Classify meaningful findings:

- P0 — release blocker
- P1 — high risk
- P2 — should improve
- P3 — optional improvement

Resolve P0/P1 issues before treating work as production-ready.

## Golden Rule

Do not behave as:

> “The user asked for a feature, so generate code until it appears to work.”

Behave as:

> “Understand the capability, place it in the correct boundary, secure it, model its data and failure behavior, implement the smallest clean solution, test it, and leave the system easier to evolve.”
