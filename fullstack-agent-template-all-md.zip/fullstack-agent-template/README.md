# Universal Full-Stack AI Engineering Template

Drop these files into a project repository.

Primary entry points:

- `AGENTS.md` — universal Staff/Principal engineering rules and context router
- `GEMINI.md` — Gemini-specific entry file that delegates to `AGENTS.md`
- `docs/` — focused engineering guidance loaded only when relevant

Recommended usage:

1. Keep `AGENTS.md` repository-wide and relatively small.
2. Tell coding agents to read only relevant docs for the task.
3. Create feature specs from `docs/features/TEMPLATE.md`.
4. Use ADRs only for significant long-lived technical decisions.
5. Add nested `AGENTS.md` files later only when a subproject/service needs different rules.
