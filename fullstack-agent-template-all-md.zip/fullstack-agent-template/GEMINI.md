# GEMINI.md

Use `AGENTS.md` as the repository-wide engineering instruction source.

Before significant implementation:

1. Read `AGENTS.md`.
2. Determine which task-specific documents under `docs/` are relevant.
3. Read only those relevant documents instead of loading the entire documentation set.
4. Follow existing project conventions unless a documented architectural change is justified.
5. For security-sensitive work, always read `docs/security.md`.
6. For major architectural decisions, use `docs/adr/TEMPLATE.md`.

Keep changes scoped, production-oriented, and consistent with the repository architecture.
