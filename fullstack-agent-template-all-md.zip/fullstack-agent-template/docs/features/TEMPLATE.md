# Feature Specification — [Feature Name]

## Purpose

[What user/business problem does this solve?]

## User Story

As a [user],
I want [capability],
so that [outcome].

## Scope

### In Scope
- ...

### Out of Scope
- ...

## User Flow

```text
Start
→ ...
→ Success
```

## Acceptance Criteria

- Given ...
  When ...
  Then ...

## Roles / Permissions

- ...

## Data

Reads:
- ...

Writes:
- ...

## API / Integrations

- ...

## UI States

- loading
- content
- empty
- error
- unauthorized/forbidden where relevant
- degraded/offline where relevant

## Failure / Edge Cases

- ...

## Security

- authentication:
- authorization:
- ownership/tenant:
- sensitive data:
- abuse/rate limiting:

## Concurrency / Idempotency

- ...

## Performance / Scale

- expected data volume:
- expected request frequency:
- pagination/limits:
- expensive operations:

## Observability

- logs:
- metrics:
- analytics events:

## Tests

- unit:
- integration:
- authorization/security:
- end-to-end critical path:

## Definition of Done

- [ ] acceptance criteria satisfied
- [ ] security reviewed
- [ ] failures handled
- [ ] tests added
- [ ] responsive/accessibility checked where applicable
- [ ] observability added where needed
- [ ] docs updated if architecture changed
