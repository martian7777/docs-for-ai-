# Frontend Engineering Guide

Use for client architecture, state management, rendering, and browser/mobile client behavior.

## Responsibilities

Frontend should primarily:

- render application state
- collect user input
- call application APIs
- provide useful loading/error feedback
- handle navigation
- perform non-authoritative presentation logic

Do not rely on the client for authoritative security or business invariants.

## State

Prefer explicit, predictable state ownership.

Separate when useful:

- server state
- local UI state
- form state
- URL/navigation state

Avoid duplicating the same authoritative state in multiple places.

## Data Fetching

Handle:

- loading
- retries
- cancellation
- stale data
- pagination
- errors
- optimistic updates where safe

Do not fire duplicate requests unintentionally.

## Performance

Watch for:

- unnecessary re-renders
- oversized bundles
- unoptimized images
- huge DOM/component trees
- unbounded lists
- duplicate fetching
- expensive computations during render

Use lazy loading, code splitting, pagination, or virtualization when justified.

## Security

Never put privileged secrets in browser/mobile clients.

Escape/render untrusted content safely.

Use framework protections against XSS and avoid unsafe raw HTML unless sanitized.

Treat client-side validation as UX only; enforce validation again server-side.
