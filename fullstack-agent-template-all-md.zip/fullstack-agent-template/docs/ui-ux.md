# UI / UX Guide

Use for visual design, responsive behavior, accessibility, navigation, and reusable UI.

## Design Principles

Prioritize:

- clear hierarchy
- predictable navigation
- low cognitive load
- useful feedback
- consistency
- accessibility
- responsiveness
- fast perceived performance

## Design System

Prefer shared tokens for:

- color
- typography
- spacing
- radius
- elevation
- icons
- motion

Reuse existing components before creating new ones.

Do not scatter magic visual values throughout feature code.

## Responsive Design

Do not design for one viewport.

Support relevant:

- mobile
- tablet
- laptop
- desktop
- wide screens

Prefer flexible layout primitives and content constraints over hardcoded widths.

Avoid simply stretching mobile UI across desktop.

## Screen States

Significant screens should consider applicable:

- loading
- success/content
- empty
- error
- unauthorized
- forbidden
- offline/degraded
- partial content

## Accessibility

Check:

- semantic markup / roles
- keyboard navigation
- focus states/order
- screen-reader labels
- contrast
- touch target size
- zoom/font scaling
- reduced motion
- error descriptions

Do not sacrifice accessibility to preserve visual layout.

## Forms

Define:

- validation timing
- field errors
- submit/loading state
- duplicate-submit prevention
- keyboard/focus behavior
- destructive confirmations
- unsaved-change behavior when important
