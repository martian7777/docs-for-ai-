# Observability Guide

Use when adding production-critical flows, external integrations, background jobs, or diagnosing reliability/performance.

## Goal

Production should answer:

- What failed?
- How often?
- Since when?
- For which operation/customer/tenant when safe?
- How long did it take?
- Can the user recover?

## Logs

Use structured logs.

Useful safe context can include:

- request/correlation ID
- operation
- service/module
- duration
- result/error category
- safe user/tenant identifier where policy allows

Never log passwords, tokens, keys, or unnecessary sensitive data.

## Metrics

Useful technical metrics:

- request rate
- latency
- error rate
- CPU/memory
- DB latency
- queue depth
- job failure/retry rate
- cache hit rate
- external API latency/error rate

## Tracing

Use tracing for multi-service or multi-dependency flows where logs alone are insufficient.

Propagate correlation identifiers.

## Product Analytics

Track meaningful user/business events, not UI implementation details.

Prefer:

```text
invoice_created
search_completed
checkout_failed
```

over:

```text
blue_button_clicked
```

## Alerts

Alert on actionable symptoms, not noisy raw events.

Examples:

- sustained error-rate increase
- latency SLO breach
- queue backlog growth
- repeated job failure
- payment/webhook processing failure
