# Database Engineering Guide

Use for schema design, migrations, queries, indexes, transactions, and data integrity.

## Schema

Use appropriate:

- primary keys
- foreign keys
- unique constraints
- NOT NULL constraints
- checks
- indexes

Prefer database constraints for true invariants.

## Modeling

Use clear domain names and ownership.

Avoid ambiguous generic tables/models.

For multi-tenant systems, make tenant/workspace/organization boundaries explicit and enforce them in queries.

## Queries

Before adding a hot-path query consider:

- row count
- selectivity
- indexes
- joins
- sorting
- pagination
- N+1 behavior
- lock behavior

Avoid unbounded reads.

Use query plans for performance-critical paths.

## Transactions

Use transactions when multiple database operations must succeed/fail together.

Keep transactions short.

Avoid network calls inside transactions.

Consider concurrency and races.

## Migrations

All production schema changes should be migration-based.

Migrations should be:

- reviewable
- repeatable
- safe on real data
- backward-compatible where rollout requires it

For large/risky changes prefer staged migration:

```text
Add new structure
→ deploy compatible code
→ backfill
→ switch reads/writes
→ remove old structure later
```

Never assume production tables are small or empty.
