# Testing & Quality Guide

Use when implementing meaningful logic or modifying critical behavior.

## Test by Risk

Prioritize:

- business invariants
- authorization
- tenant/ownership boundaries
- data integrity
- state transitions
- concurrency-sensitive behavior
- failure/retry behavior
- critical user journeys

Use the cheapest test level that gives confidence.

## Test Types

Use an appropriate mix of:

- unit tests
- integration tests
- database tests
- API/contract tests
- UI/component tests
- end-to-end tests

Do not duplicate the same assertion across every layer.

## Behavior Style

Prefer observable behavior:

```text
Given ...
When ...
Then ...
```

Avoid testing private implementation details.

## Security Tests

For sensitive endpoints consider:

- unauthenticated access
- unauthorized role
- cross-user resource access
- cross-tenant access
- malformed input
- expired/revoked session
- rate-limit behavior

## CI Quality Gates

Relevant changes should normally pass:

- formatting
- lint
- type checking
- unit tests
- integration tests
- build
- dependency/security checks where configured

Do not disable quality gates merely to make a change pass.

## Coverage

Coverage percentage is a signal, not a goal.

Prefer meaningful risk coverage over shallow line coverage.
