# Architecture Guide

Use for module boundaries, major refactors, new subsystems, or cross-cutting changes.

## Principles

Prefer:

- simple architecture
- explicit ownership
- cohesive modules
- clear contracts
- dependency direction
- incremental evolution
- reversible decisions under uncertainty

Typical dependency direction:

```text
UI / Transport
      ↓
Application
      ↓
Domain
      ↓
Contracts
      ↓
Infrastructure
```

Not every project needs every layer.

## Preferred Starting Point

For most applications, begin with a **modular monolith**.

Split into services only when justified by:

- independent scaling
- isolation/security
- deployment independence
- team ownership
- fault isolation
- materially different runtime requirements

## Feature Ownership

Prefer:

```text
features/
  auth/
  users/
  billing/
  search/

shared/
infrastructure/
```

Avoid cross-feature imports that bypass public contracts.

## Major Change Checklist

Before a major architecture change ask:

- What concrete problem exists?
- Can the current architecture support the requirement?
- What is the migration cost?
- Is the choice reversible?
- What operational burden is introduced?
- How does it affect testing and observability?
- What happens at 10x scale?
- Does the team understand it?

Use an ADR for significant long-lived decisions.

## Refactoring

Avoid big-bang rewrites.

Prefer:

```text
Current system
    ↓
Compatibility boundary
    ↓
Target architecture
```

Protect behavior with tests before migration.
