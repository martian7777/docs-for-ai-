# ADR-[NUMBER]: [Decision]

**Status:** Proposed | Accepted | Deprecated | Superseded  
**Date:** YYYY-MM-DD

## Context

What problem or constraint requires a decision?

## Decision

What are we choosing?

## Alternatives Considered

### Option A
Pros:
- ...

Cons:
- ...

### Option B
Pros:
- ...

Cons:
- ...

## Consequences

Positive:
- ...

Negative / trade-offs:
- ...

## Migration / Rollback

How can this be introduced safely?

How can it be reversed if necessary?

## Review Trigger

What future condition should cause this decision to be revisited?
