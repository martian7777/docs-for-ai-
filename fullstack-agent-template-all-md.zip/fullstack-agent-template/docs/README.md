# Engineering Docs Router

These files are intentionally split so AI agents do not need the entire engineering manual in context for every task.

| Task | Read |
|---|---|
| Feature/product requirements | `product.md` |
| Architecture/refactor/modules | `architecture.md` |
| UI/UX/responsive/accessibility | `ui-ux.md` |
| Frontend/state/client logic | `frontend.md` |
| APIs/backend/jobs/services | `backend.md` |
| Database/schema/query/migration | `database.md` |
| Auth/security/uploads/billing/admin | `security.md` |
| Scale/cache/queue/performance | `scaling-performance.md` |
| Tests/CI/quality gates | `testing.md` |
| Logs/metrics/tracing/analytics | `observability.md` |
| New feature specification | `features/TEMPLATE.md` |
| Long-lived technical decision | `adr/TEMPLATE.md` |

Do not load every file by default.
