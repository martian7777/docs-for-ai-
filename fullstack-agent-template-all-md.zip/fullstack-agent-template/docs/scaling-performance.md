# Scaling & Performance Guide

Use when throughput, latency, large datasets, caches, queues, or infrastructure scaling are relevant.

## Principle

Design for today's load while avoiding obvious traps.

Do not prematurely introduce distributed architecture.

Prefer a modular monolith until independent scaling or operational boundaries justify otherwise.

## Scaling Dimensions

Consider:

- users
- requests
- data size
- concurrent writes
- background jobs
- integrations
- developers
- deployment frequency

## Horizontal Scaling

If multiple application instances may run, do not rely on local memory or local filesystem for critical shared state.

Use shared systems where required:

- database
- object storage
- queue
- cache
- distributed coordination

## Caching

Add caching only for a clear need.

Define:

- what is cached
- key
- TTL
- invalidation
- stale behavior
- failure fallback

Do not add Redis merely because it is common.

## Queues

Use queues for slow, retryable, bursty, or independently scalable work.

Track:

- queue depth
- processing latency
- retries
- dead-letter/failure behavior

## Performance

Measure important paths.

Common backend problems:

- N+1 queries
- missing indexes
- huge payloads
- serial external calls
- excessive DB round trips
- blocking work

Common frontend problems:

- giant bundles
- unnecessary re-rendering
- huge images
- unbounded lists
- duplicate requests

## Limits

Define sane limits for:

- page size
- upload size
- request body size
- batch size
- concurrency
- AI tokens/cost where relevant

## Capacity Thinking

For important services estimate:

```text
peak requests/sec
× expensive work/request
× data volume
× expected growth
```

Optimize bottlenecks based on measurement, not fashion.
