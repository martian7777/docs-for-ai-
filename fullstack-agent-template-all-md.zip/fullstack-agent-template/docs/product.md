# Product Engineering Guide

Use this document when defining or changing product behavior.

## For Each Significant Feature

Capture:

- problem being solved
- target user
- user story / job to be done
- happy path
- important alternate paths
- acceptance criteria
- permissions/roles
- data created or changed
- failure states
- edge cases
- analytics/success metrics
- out-of-scope behavior

## Scope Discipline

Separate:

- MVP
- current release
- future ideas

Do not build speculative future functionality unless it materially affects today's architecture.

## Acceptance Criteria

Prefer observable behavior.

Example:

```text
Given a user does not own a project
When they request deletion
Then the server returns forbidden
And the project remains unchanged
```

## Product Quality

For important flows consider:

- empty states
- slow network
- partial failures
- duplicate user actions
- interrupted flows
- accessibility
- mobile/desktop behavior
- destructive-action recovery
