# Backend Engineering Guide

Use for APIs, application services, workers, integrations, and server-side business logic.

## Boundaries

Prefer:

```text
Route / Controller
       ↓
Application Service / Use Case
       ↓
Domain
       ↓
Repository / Integration Contract
```

Controllers/routes should be thin.

## APIs

Prefer:

- consistent naming
- typed/validated inputs
- structured client-safe errors
- stable identifiers
- sane payload sizes
- pagination/limits for growing collections
- explicit authorization
- backward compatibility where clients may lag

Do not expose internal database models blindly.

## External Services

Assume they can:

- timeout
- rate-limit
- fail
- return malformed data
- change behavior

Use appropriate:

- timeouts
- retries with backoff
- idempotency
- circuit breaking when justified
- validation
- observability

Do not blindly retry non-idempotent operations.

## Background Jobs

Use asynchronous jobs when work:

- is slow
- can be retried
- does not need to block the request
- needs independent throughput

Examples: email, imports, exports, media, AI processing, notifications, webhook processing.

Jobs should be idempotent where practical.

## Webhooks

Verify authenticity where supported.

Assume webhooks can be:

- duplicated
- delayed
- retried
- out of order

Deduplicate important events and offload slow processing.
