# Security Guide

Read this for authentication, authorization, uploads, billing, admin operations, external callbacks, sensitive data, or AI/tool execution.

## Trust Boundaries

Treat as untrusted:

- request bodies
- query/path parameters
- headers/cookies
- uploaded files
- webhook payloads
- external API responses
- AI/model output
- browser/mobile clients

Validate input at boundaries.

## Authentication vs Authorization

Authentication: who is the caller?

Authorization: may they perform this action on this resource?

Enforce authorization server-side for every sensitive resource/action.

Check:

```text
actor + action + resource + ownership/tenant + permission
```

Prevent IDOR/BOLA and cross-tenant access.

## Secrets

Never commit or expose:

- passwords
- API keys
- private keys
- tokens
- DB credentials
- privileged service credentials

Use managed secrets/environment configuration.

Assume frontend/mobile code is inspectable.

## Common Web Risks

Protect against applicable:

- SQL/NoSQL injection
- command injection
- XSS
- CSRF
- SSRF
- path traversal
- insecure deserialization
- open redirects
- file upload attacks
- brute force / credential stuffing
- mass assignment
- IDOR/BOLA

Use parameterized queries and allowlists where appropriate.

## Sessions / Tokens

Use secure cookies where applicable:

- Secure
- HttpOnly
- SameSite appropriate to the flow

Centralize token/session verification, expiry, refresh, revocation, and logout behavior.

## Passwords

Never store plaintext passwords.

Use a well-established password hashing algorithm such as Argon2id, bcrypt, or scrypt with appropriate configuration.

Never invent cryptography.

## Sensitive Data

Minimize collection and retention.

Do not log:

- passwords
- tokens
- private keys
- payment secrets
- unnecessary PII

Encrypt sensitive data where justified.

## Uploads

Treat files as hostile.

Validate:

- size
- extension
- MIME/type
- ownership
- storage destination

Generate server-controlled filenames where practical.

Do not store untrusted uploads in executable locations.

## Rate Limiting

Consider limits for:

- login/signup
- password reset / OTP
- public forms
- uploads
- expensive search
- AI endpoints
- sensitive mutations

## Billing / Payments

Never trust client payment status.

Verify server-side/provider-side.

Handle duplicate callbacks, retries, refunds, delayed confirmation, and idempotency.

## AI / Agents

Treat model output as untrusted.

Validate structured outputs.

Do not automatically execute generated SQL, shell commands, URLs, code, or privileged tool actions without strict controls.

Protect tool-enabled systems against prompt injection and excessive permissions.

Use least privilege.

## Security Completion Check

For sensitive changes confirm:

- authentication correct
- authorization tested
- ownership/tenant boundary enforced
- input validated
- secrets protected
- sensitive logs avoided
- abuse/rate limits considered
- failure behavior safe
- security tests added where valuable
