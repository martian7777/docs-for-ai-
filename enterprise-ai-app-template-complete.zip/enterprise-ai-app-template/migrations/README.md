# Database Migrations

Store all production schema changes here, or in the migration directory required by the chosen ORM/framework.

Rules:

- schema changes must be version controlled
- do not modify production schema manually
- review destructive changes carefully
- assume real production data exists
- prefer staged/backward-compatible migrations for risky changes
