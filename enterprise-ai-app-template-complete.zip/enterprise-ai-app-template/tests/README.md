# Tests

Organize tests according to the chosen stack.

Prioritize:

- business rules
- authorization
- tenant/ownership isolation
- data integrity
- failure behavior
- concurrency-sensitive operations
- critical user journeys

Do not optimize for coverage percentage alone.
