# Scripts

Place repeatable operational/development scripts here.

Examples:

- seed data
- data backfills
- one-time migrations
- import/export tools
- local setup
- smoke tests

Scripts that modify production data must be explicit, reviewable, and safe to rerun where practical.
