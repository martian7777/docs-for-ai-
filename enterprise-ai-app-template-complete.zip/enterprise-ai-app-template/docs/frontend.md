# Frontend Engineering

## Responsibilities

Frontend should primarily:

- render application state
- collect user input
- call application APIs
- provide useful loading/error feedback
- handle navigation
- perform non-authoritative presentation logic

Do not rely on the client for authoritative security or business invariants.

## Project Frontend Stack

Fill if applicable:

```text
Framework: [FRAMEWORK]
Language: [LANGUAGE]
State/Data: [STATE/DATA_LIBRARIES]
Styling: [STYLING]
Testing: [FRONTEND_TESTING]
```

## State

Prefer explicit ownership.

Separate where useful:

- server state
- local UI state
- form state
- navigation/URL state

Avoid duplicating authoritative state.

## Data Fetching

Handle:

- loading
- cancellation
- retries
- stale data
- pagination
- errors
- safe optimistic updates

## Performance

Watch for:

- unnecessary re-renders
- oversized bundles
- huge images
- unbounded lists
- duplicate fetching
- expensive render-time computation

Use lazy loading/code splitting/virtualization only where useful.

## Security

Never put privileged secrets in the client.

Render untrusted content safely.

Treat client-side validation as UX; enforce again server-side.
