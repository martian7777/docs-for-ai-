# Threat Model

> Fill for each application. Keep this concrete and app-specific.

## Assets

What must be protected?

- `[ASSET]`
- `[ASSET]`

## Actors

- Legitimate user: `[DESCRIPTION]`
- Admin: `[DESCRIPTION]`
- External attacker: `[DESCRIPTION]`
- Third-party integration: `[DESCRIPTION]`

## Trust Boundaries

```text
[CLIENT]
   ↓
[PUBLIC API]
   ↓
[APPLICATION]
   ├── [DATABASE]
   ├── [STORAGE]
   └── [THIRD-PARTY SERVICES]
```

## Authentication / Authorization Model

`[DESCRIBE]`

## Major Threats

| Threat | Impact | Likelihood | Mitigation |
|---|---|---|---|
| `[THREAT]` | `[H/M/L]` | `[H/M/L]` | `[MITIGATION]` |

Consider:

- account takeover
- privilege escalation
- IDOR/BOLA
- cross-tenant leakage
- malicious uploads
- webhook spoofing
- API abuse
- payment fraud
- prompt injection
- data exfiltration
- admin misuse

## Sensitive Data

- `[DATA_CATEGORY]`

## Security Assumptions

- `[ASSUMPTION]`

## Review Triggers

Revisit this threat model when:

- authentication changes
- permissions change
- billing is added
- uploads are added
- AI/tool execution is added
- new third parties are integrated
- multi-tenancy is introduced
