# Architecture

## Principles

Prefer:

- simple architecture
- explicit ownership
- cohesive modules
- clear contracts
- dependency direction
- incremental evolution
- reversible decisions under uncertainty

Typical dependency direction:

```text
UI / Transport
      ↓
Application
      ↓
Domain
      ↓
Contracts
      ↓
Infrastructure
```

Not every project needs every layer.

## Default Starting Point

Prefer a **modular monolith** for most new applications.

Split into services only when justified by:

- independent scaling
- fault/security isolation
- independent deployment
- team ownership
- materially different runtime needs

## App-Specific Architecture

Fill for this project:

```text
[HIGH_LEVEL_SYSTEM_DIAGRAM]
```

### Main Modules

- `[MODULE]` — `[RESPONSIBILITY]`

### Dependency Rules

- `[PROJECT_SPECIFIC_RULE]`

## Major Change Checklist

Before a major architecture change ask:

- What concrete problem exists?
- Can the current architecture support it?
- What is the migration cost?
- Is the choice reversible?
- What operational burden is introduced?
- How does it affect testing/observability?
- What happens at 10x scale?
- Does the team understand it?

Use an ADR for significant long-lived decisions.

## Refactoring

Avoid big-bang rewrites.

Prefer:

```text
Current system
→ compatibility boundary
→ target architecture
```
