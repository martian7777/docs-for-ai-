# API

> Fill project-specific conventions before building many endpoints.

## API Style

`[REST / GRAPHQL / RPC / OTHER]`

## Base Path

`[e.g. /api/v1]`

## Authentication

`[SESSION / JWT / OAUTH / OTHER]`

## ID Format

`[UUID / ULID / INTEGER / OTHER]`

## Date/Time Format

Recommended:

```text
ISO-8601
UTC for absolute timestamps
```

Project decision:

`[FORMAT]`

## Money

Recommended:

```text
integer minor units + currency code
```

Project decision:

`[FORMAT]`

## Success Envelope

```json
{
  "data": {}
}
```

Project variation:

`[OPTIONAL]`

## Error Envelope

```json
{
  "error": {
    "code": "STABLE_MACHINE_CODE",
    "message": "Client-safe message"
  }
}
```

## Pagination

`[CURSOR / OFFSET / OTHER]`

Default page size: `[NUMBER]`

Maximum page size: `[NUMBER]`

## Versioning / Compatibility

`[STRATEGY]`

## Endpoint Conventions

Example:

```text
GET    /resources
POST   /resources
GET    /resources/:id
PATCH  /resources/:id
DELETE /resources/:id
```

## Rate Limits

`[GLOBAL/PER-ENDPOINT STRATEGY]`

## Idempotency

Required for:

- `[ENDPOINT/OPERATION]`

## API Contract Source

`[OPENAPI / GRAPHQL SCHEMA / CODE-FIRST / OTHER]`
