# Product

> Fill the placeholders below for each application.

## Product Name

`[APP_NAME]`

## Product Vision

`[WHAT_THE_PRODUCT_DOES_AND_WHY_IT_EXISTS]`

## Primary Users

- `[USER_TYPE_1]`
- `[USER_TYPE_2]`

## Main Problems Solved

- `[PROBLEM_1]`
- `[PROBLEM_2]`

## Core Jobs To Be Done

- `[JOB_1]`
- `[JOB_2]`

## Primary User Journeys

```text
[ENTRY]
→ [STEP]
→ [STEP]
→ [SUCCESS]
```

## MVP Features

- `[FEATURE]`

## Current Release Scope

- `[FEATURE]`

## Future Ideas

- `[OPTIONAL_FUTURE_IDEA]`

Do not implement future ideas unless they materially affect current architecture.

## Product Constraints

- `[OFFLINE_REQUIREMENT]`
- `[REGION/COMPLIANCE_REQUIREMENT]`
- `[DEVICE/PLATFORM_REQUIREMENT]`

## Success Metrics

- `[METRIC]`

## Feature Quality

Important flows should consider:

- loading
- empty states
- errors
- slow network
- duplicate actions
- interrupted flows
- accessibility
- responsive behavior
