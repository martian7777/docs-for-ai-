# UI / UX

## Principles

Prioritize:

- clear hierarchy
- predictable navigation
- low cognitive load
- useful feedback
- consistency
- accessibility
- responsive behavior
- fast perceived performance

## App-Specific Design Direction

### Visual Style

`[STYLE: e.g. minimal / enterprise / playful / dark / editorial]`

### Brand Colors

- Primary: `[COLOR]`
- Secondary: `[COLOR]`
- Background: `[COLOR]`
- Surface: `[COLOR]`
- Success: `[COLOR]`
- Warning: `[COLOR]`
- Error: `[COLOR]`

### Typography

`[FONT_FAMILY / SYSTEM_FONT]`

### Spacing / Radius

`[DESIGN_TOKEN_NOTES]`

## Design System

Reuse shared tokens for:

- color
- typography
- spacing
- radius
- elevation
- icons
- motion

Search for an existing component before creating a new one.

## Responsive Design

Support relevant:

- mobile
- tablet
- laptop
- desktop
- wide screens

Prefer flexible layouts and content constraints over hardcoded dimensions.

## Screen States

Consider applicable:

- loading
- content
- empty
- error
- unauthorized
- forbidden
- degraded/offline
- partial content

## Accessibility

Check:

- semantic structure
- keyboard navigation
- focus states/order
- screen-reader labels
- contrast
- touch target size
- zoom/font scaling
- reduced motion
- clear error descriptions

## Forms

Define:

- validation timing
- field errors
- loading/submission state
- duplicate-submit prevention
- keyboard/focus behavior
- destructive confirmations
- unsaved-change behavior where important
