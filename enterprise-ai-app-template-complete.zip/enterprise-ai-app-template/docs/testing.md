# Testing & Quality

## Test by Risk

Prioritize:

- business invariants
- authorization
- tenant/ownership boundaries
- data integrity
- state transitions
- concurrency-sensitive behavior
- failure/retry behavior
- critical user journeys

## Test Types

Use an appropriate mix of:

- unit
- integration
- database
- API/contract
- UI/component
- end-to-end

Use the cheapest test level that provides confidence.

## Behavior Style

Prefer:

```text
Given ...
When ...
Then ...
```

## Security Tests

For sensitive endpoints consider:

- unauthenticated
- wrong role
- cross-user access
- cross-tenant access
- malformed input
- expired/revoked session
- abuse/rate-limit behavior

## CI Quality Gates

Relevant changes should normally pass:

- formatting
- lint
- type checking
- unit tests
- integration tests
- build
- security/dependency checks where configured

Do not disable gates just to make a change pass.

## Project Commands

Fill once stack is chosen:

```text
Format: [COMMAND]
Lint: [COMMAND]
Typecheck: [COMMAND]
Unit tests: [COMMAND]
Integration tests: [COMMAND]
Build: [COMMAND]
All checks: [COMMAND]
```
