# Deployment

> Fill provider-specific details for each application.

## Deployment Architecture

```text
Git Repository
    ↓
CI
    ↓
Build / Tests / Security Checks
    ↓
Artifact / Container
    ↓
[DEPLOYMENT PLATFORM]
    ↓
Application
    ├── Database
    ├── Object Storage
    ├── Queue/Workers
    └── External Services
```

## Hosting

Frontend: `[PROVIDER]`

Backend: `[PROVIDER]`

Database: `[PROVIDER]`

Object Storage: `[PROVIDER]`

Queue/Workers: `[PROVIDER/NOT_USED]`

DNS/CDN: `[PROVIDER]`

## Deployment Strategy

`[ROLLING / BLUE-GREEN / CANARY / OTHER]`

## Database Migrations

Define sequence:

```text
[WHEN/HOW MIGRATIONS RUN]
```

Prefer backward-compatible migrations for zero/low-downtime deployment.

## Health Checks

- Liveness: `[ENDPOINT/STRATEGY]`
- Readiness: `[ENDPOINT/STRATEGY]`

## Rollback

Application rollback:

`[PROCESS]`

Migration rollback:

`[PROCESS / FORWARD-FIX STRATEGY]`

## Backups

Database backup frequency: `[FREQUENCY]`

Retention: `[RETENTION]`

Restore test frequency: `[FREQUENCY]`

Object storage backup/versioning: `[STRATEGY]`

## Recovery Objectives

RPO: `[TARGET]`

RTO: `[TARGET]`

## Production Release Checklist

- [ ] CI green
- [ ] migrations reviewed
- [ ] secrets/config verified
- [ ] rollback path understood
- [ ] monitoring/alerts active
- [ ] critical smoke tests pass
