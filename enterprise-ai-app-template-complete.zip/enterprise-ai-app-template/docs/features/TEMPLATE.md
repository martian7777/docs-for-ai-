# Feature Specification — [FEATURE_NAME]

## Purpose

`[PROBLEM_SOLVED]`

## User Story

As a `[USER]`,
I want `[CAPABILITY]`,
so that `[OUTCOME]`.

## Scope

### In Scope

- `[ITEM]`

### Out of Scope

- `[ITEM]`

## User Flow

```text
[START]
→ [STEP]
→ [SUCCESS]
```

## Acceptance Criteria

- Given `[STATE]`
  When `[ACTION]`
  Then `[EXPECTED_RESULT]`

## Roles / Permissions

- `[ROLE]`: `[ALLOWED_ACTIONS]`

## Data

Reads:

- `[DATA]`

Writes:

- `[DATA]`

## API / Integrations

- `[ENDPOINT/SERVICE]`

## UI States

- loading
- content
- empty
- error
- unauthorized/forbidden where relevant
- degraded/offline where relevant

## Failure / Edge Cases

- `[CASE]`

## Security

- authentication: `[RULE]`
- authorization: `[RULE]`
- ownership/tenant: `[RULE]`
- sensitive data: `[RULE]`
- abuse/rate limiting: `[RULE]`

## Concurrency / Idempotency

`[RULE]`

## Performance / Scale

- expected data volume: `[VALUE]`
- expected request frequency: `[VALUE]`
- pagination/limits: `[VALUE]`
- expensive operations: `[VALUE]`

## Observability

- logs: `[EVENTS]`
- metrics: `[METRICS]`
- analytics: `[EVENTS]`

## Tests

- unit: `[CASES]`
- integration: `[CASES]`
- authorization/security: `[CASES]`
- E2E: `[CRITICAL_PATH]`

## Definition of Done

- [ ] acceptance criteria satisfied
- [ ] security reviewed
- [ ] failures handled
- [ ] tests added
- [ ] responsive/accessibility checked where applicable
- [ ] observability added where needed
- [ ] docs updated if architecture changed
