# Scaling & Performance

## Principle

Design for today's load while avoiding obvious traps.

Do not prematurely introduce distributed architecture.

Prefer a modular monolith until independent scaling or operational boundaries justify otherwise.

## Expected Scale

Fill for this application:

```text
Initial users: [NUMBER]
12-month users: [NUMBER]
Peak requests/sec: [NUMBER/UNKNOWN]
Primary dataset size: [ESTIMATE]
Largest expected upload: [SIZE]
Background jobs/day: [ESTIMATE]
```

## Scaling Dimensions

Consider:

- users
- requests
- data size
- concurrent writes
- background jobs
- integrations
- developers
- deployment frequency

## Horizontal Scaling

If multiple app instances may run, do not rely on local memory/filesystem for critical shared state.

## Caching

Add only for a clear need.

Define:

- what
- key
- TTL
- invalidation
- stale behavior
- fallback

Do not add Redis by default.

## Queues

Use for slow, retryable, bursty, or independently scalable work.

Track:

- queue depth
- processing latency
- retries
- dead-letter/failure behavior

## Performance Targets

Fill where relevant:

```text
API p95 latency: [TARGET]
Page/app load: [TARGET]
Critical DB query: [TARGET]
Background job completion: [TARGET]
```

## Limits

Define sane:

- page size
- upload size
- request body size
- batch size
- concurrency
- AI tokens/cost where relevant

Measure bottlenecks before complex optimization.
