# Environments

> Fill this for each application.

## Environment Matrix

| Environment | Purpose | Data | External Services | Secrets |
|---|---|---|---|---|
| Local | Development | `[LOCAL DATA]` | `[FAKE/SANDBOX]` | local env |
| Test | Automated tests | isolated | mocked/test | test secrets |
| Staging | Pre-production validation | `[STAGING DATA]` | sandbox/real-safe | managed |
| Production | Real users | production | production | managed |

## Environment Rules

- Production secrets never go into source control.
- Environment differences should be configuration-driven, not code forks.
- Validate required configuration on startup.
- Fail clearly if required production config is missing.
- Do not silently use insecure defaults.

## URLs / Domains

- Local: `[URL]`
- Staging: `[URL]`
- Production: `[URL]`

## Database Strategy

- Local: `[DB]`
- Test: `[DB]`
- Staging: `[DB]`
- Production: `[DB]`

## Third-Party Modes

Payments: `[SANDBOX/PROD DETAILS]`

Email: `[LOCAL/STAGING/PROD DETAILS]`

Storage: `[DETAILS]`

Other integrations:

- `[SERVICE]`: `[ENVIRONMENT BEHAVIOR]`
