# Data Model

> Fill this before substantial schema work. This is the canonical domain ownership map.

## Core Entities

### `[ENTITY_NAME]`

Purpose: `[WHY_IT_EXISTS]`

Fields:

- `id`: `[TYPE]`
- `[field]`: `[TYPE]`

Owned by: `[USER / ORG / SYSTEM / OTHER]`

Relationships:

- `[RELATIONSHIP]`

Invariants:

- `[RULE]`

---

## Entity Relationships

```text
[ENTITY_A]
    │
    ├── [ENTITY_B]
    │
    └── [ENTITY_C]
```

## Ownership Model

```text
[USER / ORGANIZATION / WORKSPACE]
        ↓
[OWNED_RESOURCES]
```

## Multi-Tenancy

`[NOT_APPLICABLE / DESCRIBE_TENANT_MODEL]`

## Deletion Strategy

For each important entity specify:

- hard delete
- soft delete
- archive
- anonymize

## Audit Requirements

`[WHAT_MUST_BE_AUDITED]`

## Data Retention

`[RETENTION_REQUIREMENTS]`

## Naming Rule

Do not create new entities/tables that duplicate an existing domain concept without updating this document.
