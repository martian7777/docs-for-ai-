# Security

Read for authentication, authorization, uploads, billing, admin operations, external callbacks, sensitive data, or AI/tool execution.

## Trust Boundaries

Treat as untrusted:

- request bodies
- query/path parameters
- headers/cookies
- uploaded files
- webhook payloads
- external API responses
- AI/model output
- browser/mobile clients

## Authentication vs Authorization

Authentication: who is the caller?

Authorization: may they perform this action on this resource?

Enforce authorization server-side for sensitive actions.

Check:

```text
actor + action + resource + ownership/tenant + permission
```

Prevent IDOR/BOLA and cross-tenant access.

## Secrets

Never commit or expose:

- passwords
- API keys
- private keys
- tokens
- DB credentials
- privileged service credentials

Use managed secrets/environment configuration.

Assume client code is inspectable.

## Common Risks

Protect against applicable:

- SQL/NoSQL injection
- command injection
- XSS
- CSRF
- SSRF
- path traversal
- insecure deserialization
- open redirects
- file upload attacks
- brute force
- mass assignment
- IDOR/BOLA

Use parameterized queries and allowlists where appropriate.

## Sessions / Tokens

Centralize verification, expiry, refresh, revocation, and logout.

Use secure cookies where applicable:

- Secure
- HttpOnly
- appropriate SameSite

## Passwords

Never store plaintext.

Use established password hashing such as Argon2id, bcrypt, or scrypt with appropriate configuration.

Never invent cryptography.

## Sensitive Data

Minimize collection and retention.

Do not log secrets, tokens, keys, payment secrets, or unnecessary PII.

## Uploads

Validate:

- size
- type
- extension
- ownership
- storage destination

Generate server-controlled filenames where practical.

## Rate Limiting

Consider for:

- login/signup
- password reset / OTP
- public forms
- uploads
- expensive search
- AI endpoints
- sensitive mutations

## Payments

Never trust client payment state.

Verify server/provider-side.

Handle duplicate callbacks, delayed confirmation, retries, refunds, and idempotency.

## AI / Agents

Treat model output as untrusted.

Validate structured output.

Do not automatically execute generated SQL, shell commands, URLs, code, or privileged tool actions without controls.

Use least privilege and defend against prompt injection.

## App-Specific Security Requirements

Fill if relevant:

- Compliance: `[NONE / GDPR / HIPAA / PCI / SOC2 / OTHER]`
- Sensitive data categories: `[LIST]`
- Authentication method: `[AUTH_METHOD]`
- Authorization model: `[RBAC / ABAC / OWNERSHIP / OTHER]`
- Multi-tenancy: `[YES/NO]`
