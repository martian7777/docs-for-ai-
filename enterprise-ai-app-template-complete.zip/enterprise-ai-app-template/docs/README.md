# Docs Router

AI agents should load only task-relevant documents.

| Task | Read |
|---|---|
| Product/feature behavior | `product.md` |
| Architecture/refactor/modules | `architecture.md` |
| UI/UX/responsive/accessibility | `ui-ux.md` |
| Frontend/state/client | `frontend.md` |
| Backend/API/jobs | `backend.md` |
| Database/schema/migrations | `database.md` |
| Authentication/security/billing/uploads/admin | `security.md` |
| App-specific attack surface | `threat-model.md` |
| API conventions/contracts | `api.md` |
| Domain entities/relationships | `data-model.md` |
| Scaling/cache/performance | `scaling-performance.md` |
| Tests/CI | `testing.md` |
| Logs/metrics/tracing | `observability.md` |
| Runtime environments | `environments.md` |
| Deployment/rollback | `deployment.md` |
| Production incidents | `runbook.md` |
| New feature | `features/TEMPLATE.md` |
| Major technical decision | `adr/TEMPLATE.md` |

Do not load all docs by default.
