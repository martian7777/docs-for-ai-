# Production Runbook

> Fill service-specific commands and links after infrastructure exists.

## Incident Basics

When production is degraded:

1. Confirm scope and user impact.
2. Check recent deployments/config changes.
3. Check error rate, latency, DB health, queues, and third parties.
4. Mitigate before deep root-cause work.
5. Roll back if the latest change is the likely cause.
6. Preserve logs/evidence.
7. Document follow-up actions.

## Common Incidents

### API Error Spike

Check:

- `[ERROR DASHBOARD]`
- recent deploys
- DB connectivity
- external dependencies
- resource saturation

Mitigation:

`[PROCEDURE]`

### Database Connectivity / Saturation

Check:

- connection count
- slow queries
- locks
- CPU/storage
- migrations

Mitigation:

`[PROCEDURE]`

### Queue Backlog

Check:

- queue depth
- worker health
- poison jobs
- third-party latency

Mitigation:

`[PROCEDURE]`

### Payment/Webhook Failures

Check:

- provider status
- signature verification
- webhook delivery logs
- deduplication/idempotency

Mitigation:

`[PROCEDURE]`

### Rollback

Command/process:

`[ROLLBACK_PROCESS]`

## Credential Rotation

`[PROCESS]`

## Restore Procedure

`[DATABASE/OBJECT STORAGE RESTORE PROCESS]`

## Escalation

Primary owner: `[OWNER]`

Secondary owner: `[OWNER]`

Provider support links: `[LINKS]`
