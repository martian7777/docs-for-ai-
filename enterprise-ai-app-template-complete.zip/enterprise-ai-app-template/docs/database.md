# Database Engineering

## Project Database

Fill for this application:

```text
Primary Database: [DATABASE]
ORM/Query Layer: [ORM_OR_QUERY_LIBRARY]
Migration Tool: [MIGRATION_TOOL]
Read Replicas: [YES/NO/NOT_YET]
```

## Schema

Use appropriate:

- primary keys
- foreign keys
- unique constraints
- NOT NULL
- checks
- indexes

Prefer database constraints for true invariants.

## Modeling

Use clear domain names and explicit ownership.

For multi-tenant systems, enforce tenant/workspace/organization boundaries in queries.

## Queries

Consider:

- expected row count
- indexes
- joins
- sorting
- pagination
- N+1
- lock behavior

Avoid unbounded reads.

Use query plans for hot paths.

## Transactions

Use when operations must succeed/fail together.

Keep short.

Avoid network calls inside transactions.

Consider races.

## Migrations

All production schema changes use migrations.

For risky/large changes prefer:

```text
add new structure
→ deploy compatible code
→ backfill
→ switch reads/writes
→ remove old structure later
```
