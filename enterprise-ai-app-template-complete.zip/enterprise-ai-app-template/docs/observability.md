# Observability

## Goal

Production should answer:

- What failed?
- How often?
- Since when?
- Which operation?
- Which tenant/user when safe?
- How long did it take?
- Can the user recover?

## Project Tooling

Fill if known:

```text
Error Reporting: [TOOL]
Logs: [TOOL]
Metrics: [TOOL]
Tracing: [TOOL]
Analytics: [TOOL]
```

## Logs

Use structured logs.

Useful safe context:

- request/correlation ID
- operation
- module/service
- duration
- result/error category
- safe user/tenant ID where permitted

Never log secrets or unnecessary sensitive data.

## Metrics

Useful technical metrics:

- request rate
- latency
- error rate
- CPU/memory
- DB latency
- queue depth
- job retry/failure rate
- cache hit rate
- external API latency/errors

## Analytics

Track business events, not UI implementation details.

Prefer:

```text
invoice_created
search_completed
checkout_failed
```

over:

```text
blue_button_clicked
```

## Alerts

Alert on actionable symptoms, such as:

- sustained error increase
- latency breach
- queue backlog
- repeated critical job failure
- payment/webhook processing failure
