# Backend Engineering

## Project Backend Stack

Fill if applicable:

```text
Framework: [FRAMEWORK]
Language: [LANGUAGE]
API Style: [REST / GraphQL / RPC / Other]
Background Jobs: [SYSTEM]
Object Storage: [SYSTEM]
```

## Boundaries

Prefer:

```text
Route / Controller
       ↓
Application Service / Use Case
       ↓
Domain
       ↓
Repository / Integration Contract
```

Keep routes/controllers thin.

## APIs

Prefer:

- typed/validated inputs
- structured client-safe errors
- stable IDs
- explicit authorization
- sane payload limits
- pagination for growing collections
- backward compatibility where older clients may exist

## External Services

Assume they can:

- timeout
- rate-limit
- fail
- return malformed data
- change behavior

Use appropriate:

- timeouts
- retries/backoff
- idempotency
- validation
- observability

Do not blindly retry non-idempotent operations.

## Background Jobs

Use async jobs for slow, retryable, bursty, or independently scalable work.

Jobs should be idempotent where practical.

## Webhooks

Verify authenticity where supported.

Assume duplicate, delayed, retried, and out-of-order delivery.

Deduplicate important events.
