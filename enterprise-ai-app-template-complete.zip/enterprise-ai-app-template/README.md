# Enterprise AI-Assisted App Engineering Template

Reusable engineering guardrails for full-stack AI-assisted development.

## Start Here

1. Fill project-specific placeholders in:
   - `docs/product.md`
   - `docs/data-model.md`
   - `docs/api.md`
   - `docs/threat-model.md`
   - `docs/environments.md`
   - `docs/deployment.md`
   - `.env.example`
2. Adapt `Makefile` commands to your stack.
3. Adapt `.github/workflows/ci.yml` and `security.yml`.
4. Copy `docs/features/TEMPLATE.md` for every significant feature.
5. Use ADRs only for meaningful long-lived decisions.

`AGENTS.md` is the canonical AI engineering instruction file.

`CLAUDE.md` and `GEMINI.md` are lightweight compatibility entry points.

## Principle

Keep universal engineering rules filled in.

Leave app-specific decisions explicit rather than allowing AI to invent them.
